﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triângulos
{
    public partial class Form1 : Form
    {
        Double A, B, C;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValordeA.Clear();
            txtValordeB.Clear();
            txtValordeC.Clear();
            txtValordeA.Focus();
        }

        private void txtValordeA_TextChanged(object sender, EventArgs e)
        {
            if (txtValordeA.Text == "")
                return;

            if (!Double.TryParse(txtValordeA.Text, out A))
                MessageBox.Show("Dado inválido");
        }

        private void txtValordeB_TextChanged(object sender, EventArgs e)
        {
            if (txtValordeB.Text == "")
                return;

            if (!Double.TryParse(txtValordeA.Text, out B))
                MessageBox.Show("Dado inválido");
        }

        private void txtValordeC_TextChanged(object sender, EventArgs e)
        {
            if (txtValordeC.Text == "")
                return;

            if (!Double.TryParse(txtValordeA.Text, out C))
                MessageBox.Show("Dado inválido");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValordeA.Text, out A) || !double.TryParse(txtValordeB.Text, out B) || !double.TryParse(txtValordeC.Text, out C))
            {
                MessageBox.Show("Os valores devem ser numéricos!");
            }
            else
            {
                if (A < (B + C) && A > Math.Abs(B - C) && B < (A + C) && B > Math.Abs(A - C) && C < (A + B) && C > Math.Abs(A - B))

                {
                    if (A == B && B == C)
                    {
                        MessageBox.Show("O triângulo é equilátero!");
                    }
                    else
                    {
                        if (A == B || A == C || C == B)
                        {
                            MessageBox.Show("O triângulo é isósceles!");
                        }
                        else
                        {
                            MessageBox.Show("O triângulo é escaleno!");
                        }

                    }
                }
                else
                {
                    MessageBox.Show("Estes valores não formam um triângulo!");
                }
            }
        }
    }
}
