﻿namespace Triângulos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValordeA = new System.Windows.Forms.Label();
            this.lblValordeB = new System.Windows.Forms.Label();
            this.lblValordeC = new System.Windows.Forms.Label();
            this.txtValordeA = new System.Windows.Forms.TextBox();
            this.txtValordeB = new System.Windows.Forms.TextBox();
            this.txtValordeC = new System.Windows.Forms.TextBox();
            this.btnExecutar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblValordeA
            // 
            this.lblValordeA.AutoSize = true;
            this.lblValordeA.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValordeA.Location = new System.Drawing.Point(151, 79);
            this.lblValordeA.Name = "lblValordeA";
            this.lblValordeA.Size = new System.Drawing.Size(96, 20);
            this.lblValordeA.TabIndex = 0;
            this.lblValordeA.Text = "Valor de A :";
            // 
            // lblValordeB
            // 
            this.lblValordeB.AutoSize = true;
            this.lblValordeB.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValordeB.Location = new System.Drawing.Point(151, 134);
            this.lblValordeB.Name = "lblValordeB";
            this.lblValordeB.Size = new System.Drawing.Size(94, 20);
            this.lblValordeB.TabIndex = 1;
            this.lblValordeB.Text = "Valor de B :";
            // 
            // lblValordeC
            // 
            this.lblValordeC.AutoSize = true;
            this.lblValordeC.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValordeC.Location = new System.Drawing.Point(152, 188);
            this.lblValordeC.Name = "lblValordeC";
            this.lblValordeC.Size = new System.Drawing.Size(95, 20);
            this.lblValordeC.TabIndex = 2;
            this.lblValordeC.Text = "Valor de C :";
            // 
            // txtValordeA
            // 
            this.txtValordeA.Location = new System.Drawing.Point(263, 81);
            this.txtValordeA.Name = "txtValordeA";
            this.txtValordeA.Size = new System.Drawing.Size(186, 20);
            this.txtValordeA.TabIndex = 3;
            this.txtValordeA.TextChanged += new System.EventHandler(this.txtValordeA_TextChanged);
            // 
            // txtValordeB
            // 
            this.txtValordeB.Location = new System.Drawing.Point(263, 136);
            this.txtValordeB.Name = "txtValordeB";
            this.txtValordeB.Size = new System.Drawing.Size(186, 20);
            this.txtValordeB.TabIndex = 4;
            this.txtValordeB.TextChanged += new System.EventHandler(this.txtValordeB_TextChanged);
            // 
            // txtValordeC
            // 
            this.txtValordeC.Location = new System.Drawing.Point(263, 190);
            this.txtValordeC.Name = "txtValordeC";
            this.txtValordeC.Size = new System.Drawing.Size(186, 20);
            this.txtValordeC.TabIndex = 5;
            this.txtValordeC.TextChanged += new System.EventHandler(this.txtValordeC_TextChanged);
            // 
            // btnExecutar
            // 
            this.btnExecutar.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExecutar.Location = new System.Drawing.Point(155, 249);
            this.btnExecutar.Name = "btnExecutar";
            this.btnExecutar.Size = new System.Drawing.Size(90, 39);
            this.btnExecutar.TabIndex = 6;
            this.btnExecutar.Text = "Executar ";
            this.btnExecutar.UseVisualStyleBackColor = true;
            this.btnExecutar.Click += new System.EventHandler(this.btnExecutar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(263, 249);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(90, 39);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(370, 249);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(90, 39);
            this.btnSair.TabIndex = 8;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 367);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnExecutar);
            this.Controls.Add(this.txtValordeC);
            this.Controls.Add(this.txtValordeB);
            this.Controls.Add(this.txtValordeA);
            this.Controls.Add(this.lblValordeC);
            this.Controls.Add(this.lblValordeB);
            this.Controls.Add(this.lblValordeA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblValordeA;
        private System.Windows.Forms.Label lblValordeB;
        private System.Windows.Forms.Label lblValordeC;
        private System.Windows.Forms.TextBox txtValordeA;
        private System.Windows.Forms.TextBox txtValordeB;
        private System.Windows.Forms.TextBox txtValordeC;
        private System.Windows.Forms.Button btnExecutar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
    }
}

