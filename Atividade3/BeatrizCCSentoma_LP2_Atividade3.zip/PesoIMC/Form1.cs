﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PesoIMC
{
    public partial class Form1 : Form
    {
        double pesoAtual, altura, imc;

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPesoAtual.Clear();
            txtAltura.Clear();
            txtPesoAtual.Focus();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)

           
        {
            if (Double.TryParse(txtPesoAtual.Text, out pesoAtual) && Double.TryParse(txtAltura.Text, out altura))
            {
                if ((pesoAtual <= 0) || (altura <= 0))
                    MessageBox.Show("Os valores devem ser maiores que zero!");
                else
                {
                    imc = pesoAtual / (Math.Pow(altura, 2));
                    imc = Math.Round(imc, 1);

                    if (imc < 18.5)
                        MessageBox.Show("Classificação: Magreza / Obesidade grau: 0");
                    else if (imc <= 24.9)
                        MessageBox.Show("Classificação: Normal / Obesidade grau: 0");
                    else if (imc <= 29.9)
                        MessageBox.Show("Classificação: Sobrepeso / Obesidade grau: 1");
                    else if (imc <= 39.9)
                        MessageBox.Show("Classificação: Obesidade / Obesidade grau: 2");
                    else
                        MessageBox.Show("Classificação: Obesidade Grave / Obesidade grau: 3");
                }
            }
            else
                MessageBox.Show("Valores inválidos!");
        }
    }
}
