﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDeMais_Click(object sender, EventArgs e)
        {
            lblResultado.Text = (float.Parse(txtNumero1.Text) + float.Parse(txtNumero2.Text)).ToString();
        }

        private void btnDeMenos_Click(object sender, EventArgs e)
        {
            lblResultado.Text = (float.Parse(txtNumero1.Text) - float.Parse(txtNumero2.Text)).ToString();
        }

        private void btnDeMult_Click(object sender, EventArgs e)
        {
            lblResultado.Text = (float.Parse(txtNumero1.Text) * float.Parse(txtNumero2.Text)).ToString();
        }

        private void btnDeDiv_Click(object sender, EventArgs e)
        {
            lblResultado.Text = (float.Parse(txtNumero1.Text) / float.Parse(txtNumero2.Text)).ToString();
        }

        private void btnCalcular_Click(object sender, EventArgs e)

         double numero1, numero2;
        
             if (Double.TryParse(txtNumero1.Text, out numero1) && Double.TryParse(txtNumero2.Text, out numero2))
              {

                   if ((numero1 <= 0 || (numero2) <= 0))
                  {
                    MessageBox.Show("Os valores devem ser maiores que 0");
                  }
                   else
                  {
                    double resultado;
                  resultado = numero1 + numero2;
                  }

             else
             {
              MessageBox.Show("Valores inválidos");
              txtNumero1.Focus();
             }


             txtNumero1.Focus private void btnSair_Click(object sender, EventArgs e)
             {
               Close();
             }

             private void btnLimpar_Click(object sender, EventArgs e)
             {
               txtNumero1.Clear();
               txtNumero2.Clear();
               txtResultado.Clear();
               txtNumero1.Focus();
             }


